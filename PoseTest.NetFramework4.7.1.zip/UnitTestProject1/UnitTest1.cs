﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pose;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {

        DateTime GetNow()
        {
            var result = DateTime.Now;
            return result;
        }

        [TestMethod]
        public void SubstituteStaticMethodWithShimTest()
        {
            var now = DateTime.Now;

            {
                var getNow = GetNow();
                var diffMs = (getNow - now).TotalMilliseconds;
                Assert.IsTrue(Math.Abs(diffMs) < 10);
            }

            {
                DateTime? getNow = null;
                PoseContext.Isolate(() =>
                {
                    getNow = GetNow();
                });

                var diffMs = (getNow.Value - now).TotalMilliseconds;
                Assert.IsTrue(Math.Abs(diffMs) < 100);
            }

            var dateTimeShim = Shim.Replace(() => DateTime.Now)
                                   .With(() => new DateTime(2010, 1, 1));

            {
                DateTime? getNow = null;
                PoseContext.Isolate(() =>
                {
                    getNow = GetNow();
                }, dateTimeShim);

                Assert.AreEqual(new DateTime(2010, 1, 1), getNow);
                var diffMs = (getNow.Value - now).TotalMilliseconds;
                Assert.IsFalse(Math.Abs(diffMs) < 1000);
            }
        }
    }
}
